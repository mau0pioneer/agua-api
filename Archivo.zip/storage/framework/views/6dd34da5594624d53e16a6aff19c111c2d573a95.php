<?php
  $months = [
    '01' => 'Enero',
    '02' => 'Febrero',
    '03' => 'Marzo',
    '04' => 'Abril',
    '05' => 'Mayo',
    '06' => 'Junio',
    '07' => 'Julio',
    '08' => 'Agosto',
    '09' => 'Septiembre',
    '10' => 'Octubre',
    '11' => 'Noviembre',
    '12' => 'Diciembre',
  ];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>
<body>
  
  
  <?php $__currentLoopData = $dwellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $street_dwellings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h1
    style="
      text-align: center;
      margin: 2rem 0;
      text-transform: uppercase;
    "
  >
    Calle: <?php echo e($street_dwellings[0]->street->name); ?>

  </h1>
  <ul>
    <?php $__currentLoopData = $street_dwellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dwelling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $total = 0;
      ?>
      
      <li
        style="
          border: 1px solid #000;
          padding: 10px;
          margin: 10px;
          list-style: none;
        "
      >
        <p>Dirección: <?php echo e($dwelling->street->name); ?> <?php echo e($dwelling->street_number); ?> <?php echo e($dwelling->interior_number); ?></p>
        
        <p>
          Periodos: 
          <div style="display: grid; gap: 1rem;">
            <?php $__currentLoopData = $dwelling->periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($period->status === 'pending'): ?>
            <?php
              $total += $period->amount;
            ?>
            <div>
              <div>
                <?php echo e($months[$period->month]); ?> - <?php echo e($period->year); ?>

              </div>
              <div>
                Costo: $<?php echo e(number_format($period->amount, 2)); ?>

              </div>
            </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </p>
        <p>
          Total pendiente: $<?php echo e(number_format($total, 2)); ?>

        </p>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/dwellings.blade.php ENDPATH**/ ?>