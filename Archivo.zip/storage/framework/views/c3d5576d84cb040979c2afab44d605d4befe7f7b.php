
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
  <div class="container pt-2">
    
    

    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">ID</th>
          <th scope="col">Nombre</th>
          <th scope="col">Dirección</th>
          <th scope="col">Teléfono</th>
          <th scope="col">Fecha y hora</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $neighbors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $neighbor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr style="text-transform: uppercase;">
            <th>
              <?php echo e($i+1); ?>

            </th>
            <th scope="row"><?php echo e($neighbor->id); ?></th>
            <td><?php echo e($neighbor->firstname . ' ' . $neighbor->lastname); ?></td>
            <td>
              <?php $__currentLoopData = $neighbor->contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($contribution->dwelling->street->name . ' ' . $contribution->dwelling->street_number . ' ' . $contribution->dwelling->interior_number); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><?php echo e($neighbor->phone_number); ?></td>
            <td></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </div>
</body>
</html><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/neighbor/index.blade.php ENDPATH**/ ?>