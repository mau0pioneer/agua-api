<?php $__env->startSection('title', 'Vecinos'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.breadcrumb', ['title' => 'Vecino'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="text-3xl text-black pb-6 capitalize">
  <?php echo e($neighbor->firstname); ?> <?php echo e($neighbor->lastname); ?>

</h1>
<div class="w-full">
  <p class="text-xl pb-3 flex items-center">
    Datos del vecino
  </p>

  <div class="bg-white p-3 rounded-lg">
    
    <p class="text-lg">
      <i class="fas fa-phone-alt mr-3"></i>
      <?php if($neighbor->phone_number): ?>
        <?php echo e($neighbor->phone_number); ?>

      <?php else: ?>
        <span class="text-gray-400 italic">Sin teléfono</span>
      <?php endif; ?>
    </p>

    
    <p class="text-lg">
      <i class="fas fa-comment mr-3"></i>
      <?php if($neighbor->comments): ?>
        <?php echo e($neighbor->comments); ?>

      <?php else: ?>
        <span class="text-gray-400 italic">Sin comentarios</span>
      <?php endif; ?>
    </p>
  </div>

  <div class="mt-10">
    <h2 class="text-2xl text-black pb-4">
      Viviendas
    </h2>

    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <?php $__currentLoopData = $neighbor->dwellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dwelling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.dwellings.show', $dwelling->uuid)); ?>" class="bg-white p-3 rounded-lg">
          <div class="text-lg capitalize">
            <i class="fas fa-home mr-3"></i>
            <?php echo e($dwelling->street->name); ?> <?php echo e($dwelling->street_number); ?> <?php echo e($dwelling->interior_number); ?>

          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

  <div class="mt-10">
    
    <h2 class="text-2xl text-black pb-4">
      Contribuciones
    </h2>

    <?php
      $contributions = $neighbor->contributions;
    ?>
    <?php echo $__env->make('contribution.table', [
      'view_comments' => true,
      'hidden_neighbor' => false,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/admin/show-neighbor.blade.php ENDPATH**/ ?>