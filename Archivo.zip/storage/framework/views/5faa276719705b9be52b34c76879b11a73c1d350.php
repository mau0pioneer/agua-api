<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $folios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $folio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $color = 'warning';
                    if($folio['CANCELADO']) $color = 'danger';
                    if($folio['FECHA'] && $folio['CANTIDAD']) $color = 'success';
                ?>
                <?php if($index % 23 == 0): ?>
                    <div class="col-md-4">
                        <ul class="list-group">
                <?php endif; ?>
                            <li class="list-group-item p-1 m-0 fs-7 list-group-item-<?php echo e($color); ?>" style="font-size: .8rem">
                                <strong>FOLIO:</strong> <?php echo e($folio['FOLIO']); ?><br>
                                <strong>EMITIDO POR:</strong> <?php echo e($folio['COLECTOR']); ?><br>
                                <strong>CANTIDAD:</strong> <?php echo e($folio['CANTIDAD']); ?><br>
                            </li>
                <?php if(($index + 1) % 23 == 0 || $index == count($folios) - 1): ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/home.blade.php ENDPATH**/ ?>