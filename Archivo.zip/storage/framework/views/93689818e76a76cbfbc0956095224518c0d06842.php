<?php
  $typeNames = [
    '1' => 'Un nivel',
    '2' => 'Dos niveles',
    '3' => 'Departamento cuadruplex',
    '4' => 'Departamento Sextuplex',
  ];
?>

<table class="min-w-full bg-white">
  <thead class="bg-gray-800 text-white">
      <tr>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">ID</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Dirección</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Estado</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Tipo</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Acciones</th>
      </tr>
  </thead>
  <tbody class="text-gray-700">
      <?php $__currentLoopData = $dwellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dwelling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="hover:bg-gray-100">
            <td class="text-left py-3 px-4"><?php echo e($dwelling->id); ?></td>
            <td class="text-left py-3 px-4 capitalize">
              <?php echo e($dwelling->street->name ?? ''); ?> <?php echo e($dwelling->street_number); ?> <?php echo e($dwelling->interior_number); ?>

            </td>
            <td class="text-left py-3 px-4">
              <span class="inline-block w-2 h-2 rounded-full <?php echo e($dwelling->inhabited ? 'bg-blue-500' : 'bg-gray-300'); ?>"></span>
              <?php echo e($dwelling->inhabited ? 'Habitada' : 'Deshabitada'); ?>

            </td>
            <td class="text-left py-3 px-4">
              <span class="inline-block w-2 h-2 rounded-full" style="background-color: <?php echo e($dwelling->type_color); ?>"></span>
              <?php echo e($typeNames[$dwelling->type]); ?>

            </td>
            <td class="text-left py-3 px-4">
              
              <a class="text-blue-400 hover:text-blue-600 mr-2" href="<?php echo e(route('admin.dwellings.show', $dwelling->uuid)); ?>">
                <i class="fas fa-eye"></i>
              </a>

              
              <a class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-edit"></i>
              </a>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/dwelling/table.blade.php ENDPATH**/ ?>