
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
  <div class="container pt-2">
    <?php $__currentLoopData = $streetsUuids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $streetUuid => $dwellings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <div class="card mb-5">
        <div class="card-header">
          <h3 style="text-transform: uppercase;"><?php echo e($dwellings[0]->street->name); ?></h3>
        </div>

        <div class="card-body">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>Dirección</th>
                <th>Vecino</th>
                <th>Teléfono</th>
                <th>Completo</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $dwellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dwelling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-uppercase">
                  <td><?php echo e($dwelling->street->name); ?> <?php echo e($dwelling->street_number); ?> <?php echo e($dwelling->interior_number); ?></td>
                  <td>
                    <ul>
                      <?php $__currentLoopData = $dwelling->neighbors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $neighbor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-unstyled"><?php echo e($neighbor->id); ?> - <?php echo e($neighbor->firstname); ?> <?php echo e($neighbor->lastname); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </td>
                  <td>
                    <ul>
                      <?php $__currentLoopData = $dwelling->neighbors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $neighbor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-unstyled"><?php echo e($neighbor->phone_number); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </td>
                  <td></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</body>
</html><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/profet.blade.php ENDPATH**/ ?>