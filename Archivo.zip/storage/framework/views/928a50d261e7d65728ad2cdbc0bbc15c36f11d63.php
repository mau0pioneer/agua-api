<?php $__env->startSection('title', 'Vecinos'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.breadcrumb', ['title' => 'Recibo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="p-5 bg-white rounded-xl w-[350px]">
  <h1 class="text-3xl text-black capitalize">
    <?php echo e($contribution->folio); ?>

  </h1>
  <div class="w-full">
    <p class="text-xl flex items-center">
      Datos del recibo
    </p>

    <div class="bg-white p-3 rounded-lg">
      <p class="text-lg capitalize">
        <i class="fas fa-calendar-alt mr-3"></i>
        <?php echo e($contribution->created_at->isoFormat('dddd D [de] MMMM [de] YYYY')); ?>

      </p>

      <p class="text-lg">
        <i class="fas fa-money-bill-wave mr-3"></i>
        $<?php echo e(number_format($contribution->amount, 2)); ?>

      </p>

      <p class="text-lg">
        <i class="fas fa-user mr-3"></i>
        Emitido por: <?php echo e($contribution->collector->name); ?>

      </p>
    </div>
  </div>
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/admin/show-contribution.blade.php ENDPATH**/ ?>