<?php $__env->startSection('title', 'Vecinos'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.breadcrumb', ['title' => 'Vivienda'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1 class="text-3xl text-black pb-6 capitalize">
  <?php echo e($dwelling->street->name); ?> <?php echo e($dwelling->street_number); ?> <?php echo e($dwelling->interior_number); ?>

</h1>
<div class="w-full">
  <p class="text-xl pb-3 flex items-center">
    Datos de la vivienda
  </p>

  <div class="grid">
    <div class="bg-white p-3 rounded-lg">
      
      <p class="text-lg">
        Código de acceso: <a class="text-blue-500 underline" href="https://agua-recibos.web.app?accessCode=<?php echo e($dwelling->access_code); ?>" target="_blank"><?php echo e($dwelling->access_code); ?></a>
      </p>
    </div>
  </div>

  <div class="mt-10">
    <h2 class="text-2xl text-black pb-4">
      Vecinos
    </h2>

    <?php if($dwelling->neighbors->count() === 0): ?>
      <p class="text-base italic text-gray-400">
        No hay vecinos registrados.
      </p>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <?php $__currentLoopData = $dwelling->neighbors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $neighbor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.neighbors.show', $neighbor->uuid)); ?>" class="bg-white p-3 rounded-lg">
          <p class="text-lg capitalize">
            <?php echo e($neighbor->firstname); ?> <?php echo e($neighbor->lastname); ?>

          </p>
          <p class="text-lg">
            <?php echo e($neighbor->phone_number); ?>

          </p>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
  </div>

  <div class="mt-10">
    
    <h2 class="text-2xl text-black pb-4">
      Contribuciones
    </h2>

    <?php
      $contributions = $dwelling->contributions;
    ?>
    <?php echo $__env->make('contribution.table', [
      'view_comments' => true,
      'hidden_neighbor' => false,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/admin/show-dwelling.blade.php ENDPATH**/ ?>