<table class="min-w-full bg-white">
  <thead class="bg-gray-800 text-white">
      <tr>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">FOLIO</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Fecha</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Cantidad</th>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Emitido por</th>
          <?php if(!isset($hidden_neighbor)): ?>
            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Vecino</th>
          <?php endif; ?>
          <?php if(isset($view_comments) && $view_comments): ?>
            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Comentarios</th>
          <?php endif; ?>
          <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Acciones</th>
      </tr>
  </thead>
  <tbody class="text-gray-700">
      <?php $__currentLoopData = $contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $color = 'bg-yellow-50';
          if ($contribution->collector_uuid && $contribution->amount) {
            $color = 'bg-green-50';
          } else if ($contribution->status === 'canceled') {
            $color = 'bg-red-50';
          }
        ?>
        <tr class="hover:bg-gray-100 <?php echo e($color); ?>">
            <td class="text-left py-3 px-4"><?php echo e($contribution->folio); ?></td>
            <td class="text-left py-3 px-4 capitalize">
              <?php if($contribution->status === 'finalized'): ?>
                <?php echo e($contribution->created_at->isoFormat('D / MMMM / YYYY')); ?>

              <?php endif; ?>

            </td>
            <td class="text-left py-3 px-4">
              $<?php echo e(number_format($contribution->amount, 2)); ?>

            </td>
            <td class="text-left py-3 px-4"><?php echo e($contribution->collector->name ?? ''); ?></td>
            <?php if(!isset($hidden_neighbor)): ?>
            <td class="text-left py-3 px-4">
              <?php if($contribution->neighbor): ?>
                <a
                  href="<?php echo e(route('admin.neighbors.show', $contribution->neighbor_uuid)); ?>"
                  class="text-blue-400 hover:text-blue-600 capitalize"
                >
                  <?php echo e($contribution->neighbor->firstname); ?> <?php echo e($contribution->neighbor->lastname); ?>

                </a>
              <?php endif; ?>
            </td>
            <?php endif; ?>
            <?php if(isset($view_comments) && $view_comments): ?>
              <td class="text-left py-3 px-4">
                <?php if($contribution->comments): ?>
                  <?php echo e($contribution->comments); ?>

                <?php else: ?>
                  <span class="text-gray-400 italic">Sin comentarios</span>
                <?php endif; ?>
              </td>
            <?php endif; ?>
            <td class="text-left py-3 px-4">
              
              <a class="text-blue-400 hover:text-blue-600 mr-2" href="<?php echo e(route('admin.contributions.show', $contribution->uuid)); ?>">
                <i class="fas fa-eye"></i>
              </a>

              
              <a class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-edit"></i>
              </a>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table><?php /**PATH /Users/mauriciomartinez/Development/waterHomex/backend/resources/views/contribution/table.blade.php ENDPATH**/ ?>