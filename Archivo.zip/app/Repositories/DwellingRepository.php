<?php

namespace App\Repositories;

use App\Models\Dwelling;

class DwellingRepository extends Repository
{
  public function __construct(Dwelling $dwelling)
  {
    $this->model = $dwelling;
  }
}
