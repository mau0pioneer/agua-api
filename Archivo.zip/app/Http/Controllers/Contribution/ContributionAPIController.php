<?php

namespace App\Http\Controllers\Contribution;

use App\Helpers\APIHelper;
use App\Http\Controllers\APIController;
use App\Models\Contribution;
use App\Repositories\ContributionRepository;
use Illuminate\Http\Request;

class ContributionAPIController extends APIController
{
    public function __construct(ContributionRepository $contributionRepository)
    {
        $this->repository = $contributionRepository;
    }

    public function show($uuid)
    {
        try {
            $data = Contribution::where('uuid', $uuid)->first();

            if (is_null($data)) {
                APIHelper::responseFailed([
                    'message' => 'No se encontró el folio.',
                ], 404);
            }

            if ($data->status === 'finalized') {
                return response()->json([
                    'message' => 'El folio '. $data->folio.' ya fue finalizado. Intente con otro folio.'
                ], 404);
            }

            // devolver los datos en formato JSON
            return response()->json($data, 200);
        } catch (\Exception $e) {
            APIHelper::responseFailed([
                'message' => 'Ocurrió un error inesperado.',
                'errors' => $e->getMessage()
            ], 500);
        }
    }

    public function showByFolio($folio)
    {
        try {
            $data = Contribution::where('folio', "2024-TA-".$folio)->first();

            if (is_null($data)) {
                return response()->json([
                    'message' => 'No se encontró el folio.'
                ], 404);
            }

            if ($data->status === 'finalized') {
                return response()->json([
                    'message' => 'El folio '. $data->folio.' ya fue finalizado. Intente con otro folio.'
                ], 404);
            }

            // devolver los datos en formato JSON
            return response()->json($data, 200);
        } catch (\Exception $e) {
            APIHelper::responseFailed([
                'message' => 'Ocurrió un error inesperado.',
                'errors' => $e->getMessage()
            ], 500);
        }
    }
}
