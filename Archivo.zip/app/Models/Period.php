<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Ramsey\Uuid\Uuid;

class Period extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'month',
        'year',
        'status',
        'amount',
        'dwelling_uuid',
    ];

    protected $casts = [
        'amount' => 'float',
    ];

    protected $hidden = [
        'id',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($period) {
            // si no se envía el campo 'uuid' se genera uno
            if (!isset($period->uuid)) {
                $period->uuid = Uuid::uuid4()->toString();
            }
        });
    }

    public function dwelling()
    {
        return $this->belongsTo(Dwelling::class);
    }
}
